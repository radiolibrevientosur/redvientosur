const MainContent: React.FC = () => {
	return (
		<div className="p-2 sm:p-4">
			{/* Asegúrate de que los contenedores principales usen clases como 'p-2 sm:p-4' y 'rounded-lg sm:rounded-xl' para responsividad. */}
			{/* Usa tarjetas compactas para publicaciones y feed en móvil. */}
		</div>
	);
};

export default MainContent;
